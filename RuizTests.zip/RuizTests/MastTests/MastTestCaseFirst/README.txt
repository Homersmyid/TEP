This test an early version of program that is
only designed to take one step.

Also, is the GAMS solution of the same problem
as provided in Chapter 2 of Conejo et als
"Investment in Electricity Generation and Transmission"

The solutions agree