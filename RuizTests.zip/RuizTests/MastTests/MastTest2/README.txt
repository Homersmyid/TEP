This is after program is set up to automatically
add new constraints, on every repeat of master.
It still only tests one step, since the subproblem
is not included.

This agrees with results found with GAMS as
in the previous test.