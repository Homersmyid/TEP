This creates the routes created on the Powerpoint presenentation.

